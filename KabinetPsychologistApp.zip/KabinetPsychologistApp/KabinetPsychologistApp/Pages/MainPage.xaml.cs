﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace KabinetPsychologistApp.Pages
{
    public class MenuEntry
    {
        public string Title { get; set; }
        public Func<Page> Create { get; set; }
    }

    public partial class MainPage : Page
    {
        private bool menuNavigation;

        public MainPage()
        {
            InitializeComponent();

            TBUserName.Text = App.CurrentUser.FullName;
            TBUserRole.Text = App.IsAdmin ? "Администратор" : "Психолог";

            var items = new List<MenuEntry>();
            if (App.IsAdmin)
            {
                items.Add(new MenuEntry { Title = "Клиенты", Create = () => new ClientListPage() });
                items.Add(new MenuEntry { Title = "Психологи", Create = () => new PsychologistListPage() });
                items.Add(new MenuEntry { Title = "Специализации", Create = () => new SpecializationListPage() });
                items.Add(new MenuEntry { Title = "Категории проблем", Create = () => new CategoryListPage() });
                items.Add(new MenuEntry { Title = "Форматы", Create = () => new FormatListPage() });
                items.Add(new MenuEntry { Title = "Услуги", Create = () => new ServiceListPage() });
                items.Add(new MenuEntry { Title = "Сессии", Create = () => new SessionListPage() });
                items.Add(new MenuEntry { Title = "Оплаты", Create = () => new PaymentListPage() });
                items.Add(new MenuEntry { Title = "Отзывы", Create = () => new ReviewListPage() });
                items.Add(new MenuEntry { Title = "Журнал сессий", Create = () => new AuditListPage() });
                items.Add(new MenuEntry { Title = "Пользователи", Create = () => new UserListPage() });
            }
            else
            {
                items.Add(new MenuEntry { Title = "Клиенты", Create = () => new ClientListPage() });
                items.Add(new MenuEntry { Title = "Мои сессии", Create = () => new SessionListPage() });
                items.Add(new MenuEntry { Title = "Мои отзывы", Create = () => new ReviewListPage() });
            }

            MenuList.ItemsSource = items;
            MenuList.SelectedIndex = 0;
        }

        private void MenuList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MenuEntry entry = MenuList.SelectedItem as MenuEntry;
            if (entry == null)
                return;
            menuNavigation = true;
            ContentFrame.Navigate(entry.Create());
        }

        private void ContentFrame_Navigated(object sender, NavigationEventArgs e)
        {
            // при переходе из меню очищаем историю, чтобы "Назад" не возвращал на старые страницы
            if (!menuNavigation)
                return;
            menuNavigation = false;
            while (ContentFrame.CanGoBack)
                ContentFrame.RemoveBackEntry();
        }

        private void BLogout_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentUser = null;
            NavigationService.Navigate(new LoginPage());
        }
    }
}
