﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;

namespace KabinetPsychologistApp.Pages
{
    public partial class PsychologistFormPage : Page
    {
        private Psychologists context;
        private bool saved;

        public PsychologistFormPage(Psychologists item)
        {
            InitializeComponent();
            context = item;
            CBSpecialization.ItemsSource = App.DB.Specializations.OrderBy(x => x.Name).ToList();

            DataContext = context;
            TBTitle.Text = context.PsychologistID == 0 ? "Новый психолог" : "Редактирование психолога";
            Unloaded += Page_Unloaded;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            // Если форму закрыли без сохранения - возвращаем объекту значения из БД
            if (saved || context.PsychologistID == 0)
                return;
            try { App.DB.Entry(context).Reload(); }
            catch (Exception) { }
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            errorMessage += InputCheck.Text(context.FullName, "ФИО", 200, true);

            if (context.SpecializationID == 0)
                errorMessage += "Выберите специализацию\n";

            if (Validation.GetHasError(TBExperience))
                errorMessage += "Стаж должен быть целым числом\n";
            else if (context.ExperienceYears < 0 || context.ExperienceYears > 60)
                errorMessage += "Стаж должен быть от 0 до 60 лет\n";

            if (Validation.GetHasError(TBFee))
                errorMessage += "Стоимость приёма должна быть числом\n";
            else if (context.Fee <= 0 || context.Fee > 1000000)
                errorMessage += "Стоимость приёма должна быть больше 0 и не более 1 000 000\n";

            errorMessage += InputCheck.Phone(context.Phone);
            errorMessage += InputCheck.Email(context.Email);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage, "Проверьте введённые данные", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                context.FullName = context.FullName.Trim();
                context.Phone = InputCheck.NullIfEmpty(context.Phone);
                context.Email = InputCheck.NullIfEmpty(context.Email);
                if (context.PsychologistID == 0)
                    App.DB.Psychologists.Add(context);
                App.DB.SaveChanges();
                saved = true;
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                if (context.PsychologistID == 0)
                    App.DB.Entry(context).State = EntityState.Detached;
                MessageBox.Show("Не удалось сохранить данные: " + App.GetError(ex), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

    }
}
