﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;
using System.Windows.Input;

namespace KabinetPsychologistApp.Pages
{
    public partial class UserListPage : Page
    {
        private List<UserRow> allRows = new List<UserRow>();

        public UserListPage()
        {
            InitializeComponent();

        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
                LoadData();
        }

        private void LoadData()
        {
            try
            {
                allRows = (from u in App.DB.Users
                           join p in App.DB.Psychologists on u.PsychologistID equals (int?)p.PsychologistID into psychologists
                           from ps in psychologists.DefaultIfEmpty()
                           orderby u.Login
                           select new UserRow
                           {
                               Entity = u,
                               Psychologist = ps.FullName,
                               RoleTitle = u.Role == "Admin" ? "Администратор" : "Психолог"
                           }).ToList();
                ApplyFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + App.GetError(ex), "Кабинет психолога", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilter()
        {
            string q = TBSearch.Text.Trim().ToLower();
            IEnumerable<UserRow> rows = allRows;
            if (q != "")
                rows = rows.Where(x => x.Entity.Login.ToLower().Contains(q) || x.Entity.FullName.ToLower().Contains(q));
            DGMain.ItemsSource = rows.ToList();
        }

        private void TBSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DGMain != null)
                ApplyFilter();
        }

        private Users GetSelected()
        {
            var row = DGMain.SelectedItem as UserRow;
            return row == null ? null : row.Entity;
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new UserFormPage(new Users()));
        }

        private void BEdit_Click(object sender, RoutedEventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись в таблице.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigationService.Navigate(new UserFormPage(item));
        }

        private void DGMain_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (DGMain.SelectedItem != null)
                BEdit_Click(sender, e);
        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для удаления.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (item.UserID == App.CurrentUser.UserID)
            {
                MessageBox.Show("Нельзя удалить пользователя, под которым вы вошли в систему.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                App.DB.Users.Remove(item);
                App.DB.SaveChanges();
                LoadData();
            }
            catch (Exception ex)
            {
                App.DB.Entry(item).State = EntityState.Unchanged;
                MessageBox.Show("Запись не удалена. Возможно, она используется в других таблицах.\n\n" + App.GetError(ex), "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

    }
}
