﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;

namespace KabinetPsychologistApp.Pages
{
    public partial class UserFormPage : Page
    {
        private Users context;
        private bool saved;

        public UserFormPage(Users item)
        {
            InitializeComponent();
            context = item;
            CBRole.ItemsSource = new List<RoleItem>
            {
                new RoleItem { Code = "Admin", Title = "Администратор" },
                new RoleItem { Code = "Psychologist", Title = "Психолог" }
            };

            var psychologists = new List<LookupItem> { new LookupItem { Id = null, Name = "— не выбран —" } };
            psychologists.AddRange(App.DB.Psychologists.OrderBy(x => x.FullName).ToList().Select(x => new LookupItem { Id = x.PsychologistID, Name = x.FullName }));
            CBPsychologist.ItemsSource = psychologists;

            TBPasswordHint.Text = context.UserID == 0
                ? "Пароль обязателен, не менее 6 символов."
                : "Оставьте поле пустым, если пароль менять не нужно.";

            DataContext = context;
            TBTitle.Text = context.UserID == 0 ? "Новый пользователь" : "Редактирование пользователя";
            Unloaded += Page_Unloaded;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            // Если форму закрыли без сохранения - возвращаем объекту значения из БД
            if (saved || context.UserID == 0)
                return;
            try { App.DB.Entry(context).Reload(); }
            catch (Exception) { }
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            string login = (context.Login ?? "").Trim();
            if (login.Length < 3 || login.Length > 50)
                errorMessage += "Логин должен содержать от 3 до 50 символов\n";
            else if (login.Any(char.IsWhiteSpace))
                errorMessage += "Логин не должен содержать пробелов\n";
            else
            {
                int userId = context.UserID;
                if (App.DB.Users.Any(x => x.Login == login && x.UserID != userId))
                    errorMessage += "Пользователь с таким логином уже существует\n";
            }

            errorMessage += InputCheck.Text(context.FullName, "ФИО", 200, true);

            if (string.IsNullOrEmpty(context.Role))
                errorMessage += "Выберите роль\n";
            else if (context.Role == "Psychologist" && context.PsychologistID == null)
                errorMessage += "Для роли «Психолог» выберите психолога из списка\n";
            else if (context.Role != "Admin" && context.UserID == App.CurrentUser.UserID)
                errorMessage += "Нельзя снять с себя права администратора\n";

            string password = PBPassword.Password;
            if (context.UserID == 0 && password.Length == 0)
                errorMessage += "Введите пароль\n";
            else if (password.Length > 0 && (password.Length < 6 || password.Length > 50))
                errorMessage += "Пароль должен содержать от 6 до 50 символов\n";

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage, "Проверьте введённые данные", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                context.Login = login;
                context.FullName = context.FullName.Trim();
                if (context.Role == "Admin")
                    context.PsychologistID = null;
                if (password.Length > 0)
                    context.PasswordHash = PasswordHelper.Hash(password);

                if (context.UserID == 0)
                    App.DB.Users.Add(context);
                App.DB.SaveChanges();
                saved = true;
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                if (context.UserID == 0)
                    App.DB.Entry(context).State = EntityState.Detached;
                MessageBox.Show("Не удалось сохранить данные: " + App.GetError(ex), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

    }
}
