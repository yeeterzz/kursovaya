﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;
using System.Windows.Input;

namespace KabinetPsychologistApp.Pages
{
    public partial class ClientListPage : Page
    {
        private List<Clients> allRows = new List<Clients>();

        public ClientListPage()
        {
            InitializeComponent();
            if (!App.IsAdmin)
                BDelete.Visibility = Visibility.Collapsed;
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
                LoadData();
        }

        private void LoadData()
        {
            try
            {
                allRows = App.DB.Clients.OrderBy(x => x.FullName).ToList();
                ApplyFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + App.GetError(ex), "Кабинет психолога", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilter()
        {
            string q = TBSearch.Text.Trim().ToLower();
            IEnumerable<Clients> rows = allRows;
            if (q != "")
                rows = rows.Where(x => x.FullName.ToLower().Contains(q) || (x.Phone ?? "").Contains(q) || (x.Email ?? "").ToLower().Contains(q));
            DGMain.ItemsSource = rows.ToList();
        }

        private void TBSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DGMain != null)
                ApplyFilter();
        }

        private Clients GetSelected()
        {
            var row = DGMain.SelectedItem as Clients;
            return row == null ? null : row;
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ClientFormPage(new Clients()));
        }

        private void BEdit_Click(object sender, RoutedEventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись в таблице.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigationService.Navigate(new ClientFormPage(item));
        }

        private void DGMain_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (DGMain.SelectedItem != null)
                BEdit_Click(sender, e);
        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для удаления.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                App.DB.Clients.Remove(item);
                App.DB.SaveChanges();
                LoadData();
            }
            catch (Exception ex)
            {
                App.DB.Entry(item).State = EntityState.Unchanged;
                MessageBox.Show("Запись не удалена. Возможно, она используется в других таблицах.\n\n" + App.GetError(ex), "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

    }
}
