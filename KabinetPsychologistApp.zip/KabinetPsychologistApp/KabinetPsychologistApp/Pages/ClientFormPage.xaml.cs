﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;

namespace KabinetPsychologistApp.Pages
{
    public partial class ClientFormPage : Page
    {
        private Clients context;
        private bool saved;

        public ClientFormPage(Clients item)
        {
            InitializeComponent();
            context = item;
            DPBirth.DisplayDateEnd = DateTime.Today;
            if (context.ClientID != 0)
                DPBirth.SelectedDate = context.BirthDate;

            DataContext = context;
            TBTitle.Text = context.ClientID == 0 ? "Новый клиент" : "Редактирование клиента";
            Unloaded += Page_Unloaded;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            // Если форму закрыли без сохранения - возвращаем объекту значения из БД
            if (saved || context.ClientID == 0)
                return;
            try { App.DB.Entry(context).Reload(); }
            catch (Exception) { }
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            errorMessage += InputCheck.Text(context.FullName, "ФИО", 200, true);

            if (DPBirth.SelectedDate == null)
                errorMessage += "Укажите дату рождения\n";
            else if (DPBirth.SelectedDate.Value.Date > DateTime.Today)
                errorMessage += "Дата рождения не может быть позже сегодняшнего дня\n";
            else if (DPBirth.SelectedDate.Value.Date < DateTime.Today.AddYears(-120))
                errorMessage += "Укажите корректную дату рождения\n";

            errorMessage += InputCheck.Phone(context.Phone);
            errorMessage += InputCheck.Email(context.Email);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage, "Проверьте введённые данные", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                context.FullName = context.FullName.Trim();
                context.BirthDate = DPBirth.SelectedDate.Value.Date;
                context.Phone = InputCheck.NullIfEmpty(context.Phone);
                context.Email = InputCheck.NullIfEmpty(context.Email);
                if (context.ClientID == 0)
                    App.DB.Clients.Add(context);
                App.DB.SaveChanges();
                saved = true;
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                if (context.ClientID == 0)
                    App.DB.Entry(context).State = EntityState.Detached;
                MessageBox.Show("Не удалось сохранить данные: " + App.GetError(ex), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

    }
}
