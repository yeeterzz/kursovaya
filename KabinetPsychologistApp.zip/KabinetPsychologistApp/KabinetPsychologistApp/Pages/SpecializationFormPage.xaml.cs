﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;

namespace KabinetPsychologistApp.Pages
{
    public partial class SpecializationFormPage : Page
    {
        private Specializations context;
        private bool saved;

        public SpecializationFormPage(Specializations item)
        {
            InitializeComponent();
            context = item;


            DataContext = context;
            TBTitle.Text = context.SpecializationID == 0 ? "Новая специализация" : "Редактирование специализации";
            Unloaded += Page_Unloaded;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            // Если форму закрыли без сохранения - возвращаем объекту значения из БД
            if (saved || context.SpecializationID == 0)
                return;
            try { App.DB.Entry(context).Reload(); }
            catch (Exception) { }
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            errorMessage += InputCheck.Text(context.Name, "Название", 200, true);
            if (!string.IsNullOrWhiteSpace(context.Name))
            {
                string name = context.Name.Trim();
                int id = context.SpecializationID;
                if (App.DB.Specializations.Any(x => x.Name == name && x.SpecializationID != id))
                    errorMessage += "Специализация с таким названием уже существует\n";
            }

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage, "Проверьте введённые данные", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                context.Name = context.Name.Trim();
                context.Description = InputCheck.NullIfEmpty(context.Description);
                if (context.SpecializationID == 0)
                    App.DB.Specializations.Add(context);
                App.DB.SaveChanges();
                saved = true;
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                if (context.SpecializationID == 0)
                    App.DB.Entry(context).State = EntityState.Detached;
                MessageBox.Show("Не удалось сохранить данные: " + App.GetError(ex), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

    }
}
