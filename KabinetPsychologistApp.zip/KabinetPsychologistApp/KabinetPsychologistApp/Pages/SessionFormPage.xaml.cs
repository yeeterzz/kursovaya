﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace KabinetPsychologistApp.Pages
{
    public partial class SessionFormPage : Page
    {
        private Sessions context;
        private bool saved;

        public SessionFormPage(Sessions item)
        {
            InitializeComponent();
            context = item;
            CBPsychologist.ItemsSource = App.DB.Psychologists.OrderBy(x => x.FullName).ToList();
            CBClient.ItemsSource = App.DB.Clients.OrderBy(x => x.FullName).ToList();
            CBService.ItemsSource = App.DB.Services.OrderBy(x => x.Name).ToList();

            if (!App.IsAdmin)
            {
                // психолог работает только со своими сессиями
                context.PsychologistID = App.CurrentUser.PsychologistID.Value;
                CBPsychologist.IsEnabled = false;
            }

            if (context.SessionID != 0)
            {
                DPDate.SelectedDate = context.SessionDateTime.Date;
                TBTime.Text = context.SessionDateTime.ToString("HH:mm");
            }
            else
            {
                TBTime.Text = "10:00";
            }
            TBPaid.Text = context.PaymentStatus ? "Да" : "Нет";

            DataContext = context;
            TBTitle.Text = context.SessionID == 0 ? "Новая сессия" : "Редактирование сессии";
            Unloaded += Page_Unloaded;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            // Если форму закрыли без сохранения - возвращаем объекту значения из БД
            if (saved || context.SessionID == 0)
                return;
            try { App.DB.Entry(context).Reload(); }
            catch (Exception) { }
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            DateTime sessionDate = DateTime.MinValue;

            if (context.PsychologistID == 0)
                errorMessage += "Выберите психолога\n";
            if (context.ClientID == 0)
                errorMessage += "Выберите клиента\n";
            if (context.ServiceID == 0)
                errorMessage += "Выберите услугу\n";

            TimeSpan sessionTime;
            if (DPDate.SelectedDate == null)
                errorMessage += "Выберите дату сессии\n";
            else if (!TimeSpan.TryParseExact(TBTime.Text.Trim(), @"h\:mm", CultureInfo.InvariantCulture, out sessionTime))
                errorMessage += "Введите время в формате ЧЧ:ММ (например, 14:30)\n";
            else
            {
                sessionDate = DPDate.SelectedDate.Value.Date + sessionTime;

                if (context.SessionID == 0 && sessionDate < DateTime.Now)
                    errorMessage += "Нельзя записать клиента на прошедшее время\n";

                if (context.PsychologistID != 0)
                {
                    int psychologistId = context.PsychologistID;
                    int sessionId = context.SessionID;
                    DateTime dateToCheck = sessionDate;
                    if (App.DB.Sessions.Any(x => x.PsychologistID == psychologistId && x.SessionDateTime == dateToCheck && x.SessionID != sessionId))
                        errorMessage += "У психолога уже есть сессия на это время\n";
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage, "Проверьте введённые данные", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                if (context.SessionID == 0)
                {
                    // Новая сессия добавляется через хранимую процедуру usp_AddSession
                    App.DB.Database.SqlQuery<int>(
                        "EXEC dbo.usp_AddSession @PsychologistID, @ClientID, @ServiceID, @SessionDT",
                        new SqlParameter("@PsychologistID", context.PsychologistID),
                        new SqlParameter("@ClientID", context.ClientID),
                        new SqlParameter("@ServiceID", context.ServiceID),
                        new SqlParameter("@SessionDT", SqlDbType.DateTime2) { Value = sessionDate }).ToList();
                }
                else
                {
                    context.SessionDateTime = sessionDate;
                    App.DB.SaveChanges();
                }
                saved = true;
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                if (context.SessionID == 0)
                    App.DB.Entry(context).State = EntityState.Detached;
                MessageBox.Show("Не удалось сохранить данные: " + App.GetError(ex), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

    }
}
