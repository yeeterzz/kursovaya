﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;

namespace KabinetPsychologistApp.Pages
{
    public partial class ReviewFormPage : Page
    {
        private Reviews context;
        private bool saved;

        public ReviewFormPage(Reviews item)
        {
            InitializeComponent();
            context = item;
            CBClient.ItemsSource = App.DB.Clients.OrderBy(x => x.FullName).ToList();
            CBPsychologist.ItemsSource = App.DB.Psychologists.OrderBy(x => x.FullName).ToList();

            var services = new List<LookupItem> { new LookupItem { Id = null, Name = "— не указана —" } };
            services.AddRange(App.DB.Services.OrderBy(x => x.Name).ToList().Select(x => new LookupItem { Id = x.ServiceID, Name = x.Name }));
            CBService.ItemsSource = services;

            CBRating.ItemsSource = new byte[] { 1, 2, 3, 4, 5 };

            DataContext = context;
            TBTitle.Text = context.ReviewID == 0 ? "Новый отзыв" : "Редактирование отзыва";
            Unloaded += Page_Unloaded;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            // Если форму закрыли без сохранения - возвращаем объекту значения из БД
            if (saved || context.ReviewID == 0)
                return;
            try { App.DB.Entry(context).Reload(); }
            catch (Exception) { }
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (context.ClientID == 0)
                errorMessage += "Выберите клиента\n";
            if (context.PsychologistID == 0)
                errorMessage += "Выберите психолога\n";
            if (context.Rating < 1 || context.Rating > 5)
                errorMessage += "Выберите оценку от 1 до 5\n";
            if (!string.IsNullOrWhiteSpace(context.Text) && context.Text.Length > 2000)
                errorMessage += "Текст отзыва не должен быть длиннее 2000 символов\n";

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage, "Проверьте введённые данные", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                context.Text = InputCheck.NullIfEmpty(context.Text);
                if (context.ReviewID == 0)
                    context.CreatedAt = DateTime.UtcNow;
                if (context.ReviewID == 0)
                    App.DB.Reviews.Add(context);
                App.DB.SaveChanges();
                saved = true;
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                if (context.ReviewID == 0)
                    App.DB.Entry(context).State = EntityState.Detached;
                MessageBox.Show("Не удалось сохранить данные: " + App.GetError(ex), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

    }
}
