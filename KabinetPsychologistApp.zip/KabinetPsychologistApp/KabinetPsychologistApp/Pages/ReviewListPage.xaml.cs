﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;
using System.Windows.Input;

namespace KabinetPsychologistApp.Pages
{
    public partial class ReviewListPage : Page
    {
        private List<ReviewRow> allRows = new List<ReviewRow>();

        public ReviewListPage()
        {
            InitializeComponent();
            if (!App.IsAdmin)
            {
                // психолог только просматривает свои отзывы
                TBPageTitle.Text = "Мои отзывы";
                BAdd.Visibility = Visibility.Collapsed;
                BEdit.Visibility = Visibility.Collapsed;
                BDelete.Visibility = Visibility.Collapsed;
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
                LoadData();
        }

        private void LoadData()
        {
            try
            {
                IQueryable<Reviews> reviews = App.DB.Reviews;
                if (!App.IsAdmin)
                {
                    int myId = App.CurrentUser.PsychologistID.Value;
                    reviews = reviews.Where(x => x.PsychologistID == myId);
                }

                allRows = (from r in reviews
                           join c in App.DB.Clients on r.ClientID equals c.ClientID
                           join p in App.DB.Psychologists on r.PsychologistID equals p.PsychologistID
                           join sv in App.DB.Services on r.ServiceID equals (int?)sv.ServiceID into services
                           from s in services.DefaultIfEmpty()
                           orderby r.CreatedAt descending
                           select new ReviewRow
                           {
                               Entity = r,
                               Client = c.FullName,
                               Psychologist = p.FullName,
                               Service = s.Name
                           }).ToList();
                ApplyFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + App.GetError(ex), "Кабинет психолога", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilter()
        {
            string q = TBSearch.Text.Trim().ToLower();
            IEnumerable<ReviewRow> rows = allRows;
            if (q != "")
                rows = rows.Where(x => x.Client.ToLower().Contains(q) || x.Psychologist.ToLower().Contains(q) || (x.Service ?? "").ToLower().Contains(q) || (x.Entity.Text ?? "").ToLower().Contains(q));
            DGMain.ItemsSource = rows.ToList();
        }

        private void TBSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DGMain != null)
                ApplyFilter();
        }

        private Reviews GetSelected()
        {
            var row = DGMain.SelectedItem as ReviewRow;
            return row == null ? null : row.Entity;
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ReviewFormPage(new Reviews()));
        }

        private void BEdit_Click(object sender, RoutedEventArgs e)
        {
            if (!App.IsAdmin)
                return;

            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись в таблице.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigationService.Navigate(new ReviewFormPage(item));
        }

        private void DGMain_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (DGMain.SelectedItem != null)
                BEdit_Click(sender, e);
        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для удаления.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                App.DB.Reviews.Remove(item);
                App.DB.SaveChanges();
                LoadData();
            }
            catch (Exception ex)
            {
                App.DB.Entry(item).State = EntityState.Unchanged;
                MessageBox.Show("Запись не удалена. Возможно, она используется в других таблицах.\n\n" + App.GetError(ex), "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

    }
}
