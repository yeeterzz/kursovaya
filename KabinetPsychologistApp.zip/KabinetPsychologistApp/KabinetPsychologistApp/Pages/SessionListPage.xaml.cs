﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;
using System.Windows.Input;

namespace KabinetPsychologistApp.Pages
{
    public partial class SessionListPage : Page
    {
        private List<SessionRow> allRows = new List<SessionRow>();

        public SessionListPage()
        {
            InitializeComponent();
            if (!App.IsAdmin)
            {
                TBPageTitle.Text = "Мои сессии";
                BDelete.Visibility = Visibility.Collapsed;
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
                LoadData();
        }

        private void LoadData()
        {
            try
            {
                IQueryable<Sessions> sessions = App.DB.Sessions;
                if (!App.IsAdmin)
                {
                    int myId = App.CurrentUser.PsychologistID.Value;
                    sessions = sessions.Where(x => x.PsychologistID == myId);
                }

                allRows = (from s in sessions
                           join p in App.DB.Psychologists on s.PsychologistID equals p.PsychologistID
                           join c in App.DB.Clients on s.ClientID equals c.ClientID
                           join sv in App.DB.Services on s.ServiceID equals sv.ServiceID
                           orderby s.SessionDateTime descending
                           select new SessionRow
                           {
                               Entity = s,
                               Psychologist = p.FullName,
                               Client = c.FullName,
                               Service = sv.Name,
                               Paid = s.PaymentStatus ? "Да" : "Нет"
                           }).ToList();
                ApplyFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + App.GetError(ex), "Кабинет психолога", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilter()
        {
            string q = TBSearch.Text.Trim().ToLower();
            IEnumerable<SessionRow> rows = allRows;
            if (q != "")
                rows = rows.Where(x => x.Client.ToLower().Contains(q) || x.Psychologist.ToLower().Contains(q) || x.Service.ToLower().Contains(q));
            DGMain.ItemsSource = rows.ToList();
        }

        private void TBSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DGMain != null)
                ApplyFilter();
        }

        private Sessions GetSelected()
        {
            var row = DGMain.SelectedItem as SessionRow;
            return row == null ? null : row.Entity;
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new SessionFormPage(new Sessions()));
        }

        private void BEdit_Click(object sender, RoutedEventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись в таблице.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigationService.Navigate(new SessionFormPage(item));
        }

        private void DGMain_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (DGMain.SelectedItem != null)
                BEdit_Click(sender, e);
        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для удаления.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                App.DB.Sessions.Remove(item);
                App.DB.SaveChanges();
                LoadData();
            }
            catch (Exception ex)
            {
                App.DB.Entry(item).State = EntityState.Unchanged;
                MessageBox.Show("Запись не удалена. Возможно, она используется в других таблицах.\n\n" + App.GetError(ex), "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

    }
}
