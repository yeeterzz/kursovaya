﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;
using System.Windows.Input;

namespace KabinetPsychologistApp.Pages
{
    public partial class PaymentListPage : Page
    {
        private List<PaymentRow> allRows = new List<PaymentRow>();

        public PaymentListPage()
        {
            InitializeComponent();

        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
                LoadData();
        }

        private void LoadData()
        {
            try
            {
                allRows = (from pm in App.DB.Payments
                           join s in App.DB.Sessions on pm.SessionID equals s.SessionID
                           join c in App.DB.Clients on s.ClientID equals c.ClientID
                           join p in App.DB.Psychologists on s.PsychologistID equals p.PsychologistID
                           orderby pm.PaymentDate descending
                           select new PaymentRow
                           {
                               Entity = pm,
                               Client = c.FullName,
                               Psychologist = p.FullName,
                               SessionDate = s.SessionDateTime
                           }).ToList();
                ApplyFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + App.GetError(ex), "Кабинет психолога", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilter()
        {
            string q = TBSearch.Text.Trim().ToLower();
            IEnumerable<PaymentRow> rows = allRows;
            if (q != "")
                rows = rows.Where(x => x.Client.ToLower().Contains(q) || x.Psychologist.ToLower().Contains(q) || (x.Entity.Method ?? "").ToLower().Contains(q));
            DGMain.ItemsSource = rows.ToList();
        }

        private void TBSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DGMain != null)
                ApplyFilter();
        }

        private Payments GetSelected()
        {
            var row = DGMain.SelectedItem as PaymentRow;
            return row == null ? null : row.Entity;
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new PaymentFormPage(new Payments()));
        }

    }
}
