﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;
using System.Globalization;

namespace KabinetPsychologistApp.Pages
{
    public partial class PaymentFormPage : Page
    {
        private Payments context;
        private bool saved;

        public PaymentFormPage(Payments item)
        {
            InitializeComponent();
            context = item;
            var raw = (from s in App.DB.Sessions
                       join c in App.DB.Clients on s.ClientID equals c.ClientID
                       join p in App.DB.Psychologists on s.PsychologistID equals p.PsychologistID
                       join sv in App.DB.Services on s.ServiceID equals sv.ServiceID
                       where !s.PaymentStatus
                       orderby s.SessionDateTime descending
                       select new
                       {
                           s.SessionID,
                           s.SessionDateTime,
                           Client = c.FullName,
                           Psychologist = p.FullName,
                           Due = sv.Price ?? p.Fee
                       }).ToList();

            var paid = App.DB.Payments.GroupBy(x => x.SessionID)
                                      .Select(g => new { SessionID = g.Key, Total = g.Sum(x => x.Amount) }).ToList();

            CBSession.ItemsSource = raw.Select(x =>
            {
                decimal total = paid.Where(pm => pm.SessionID == x.SessionID).Sum(pm => pm.Total);
                decimal remaining = x.Due - total;
                return new SessionItem
                {
                    SessionID = x.SessionID,
                    Remaining = remaining > 0 ? remaining : x.Due,
                    Title = x.SessionDateTime.ToString("dd.MM.yyyy HH:mm") + " — " + x.Client + " (" + x.Psychologist + ")"
                };
            }).ToList();

            CBMethod.ItemsSource = new string[] { "Карта", "Наличные", "Перевод" };
            DPDate.DisplayDateEnd = DateTime.Today;
            DPDate.SelectedDate = DateTime.Today;

            DataContext = context;
            TBTitle.Text = context.PaymentID == 0 ? "Новая оплата" : "Оплата";
            Unloaded += Page_Unloaded;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            // Если форму закрыли без сохранения - возвращаем объекту значения из БД
            if (saved || context.PaymentID == 0)
                return;
            try { App.DB.Entry(context).Reload(); }
            catch (Exception) { }
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            decimal amount = 0;
            SessionItem selectedSession = CBSession.SelectedItem as SessionItem;

            if (selectedSession == null)
                errorMessage += "Выберите сессию, за которую вносится оплата\n";

            if (!decimal.TryParse(TBAmount.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out amount) || amount <= 0)
                errorMessage += "Введите сумму оплаты (число больше 0)\n";
            else if (selectedSession != null && amount > selectedSession.Remaining)
                errorMessage += "Сумма не должна превышать остаток к оплате (" + selectedSession.Remaining.ToString("F2") + " руб.)\n";

            if (DPDate.SelectedDate == null)
                errorMessage += "Укажите дату оплаты\n";
            else if (DPDate.SelectedDate.Value.Date > DateTime.Today)
                errorMessage += "Дата оплаты не может быть в будущем\n";

            if (!string.IsNullOrWhiteSpace(context.Method) && context.Method.Trim().Length > 100)
                errorMessage += "Способ оплаты не должен быть длиннее 100 символов\n";

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage, "Проверьте введённые данные", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                context.Amount = amount;
                context.PaymentDate = DPDate.SelectedDate.Value.Date + DateTime.Now.TimeOfDay;
                context.Method = InputCheck.NullIfEmpty(context.Method);
                App.DB.Payments.Add(context);
                App.DB.SaveChanges();

                // триггер trg_Payments_UpdateStatus мог изменить статус оплаты сессии - перечитываем её
                Sessions paidSession = App.DB.Sessions.Find(context.SessionID);
                if (paidSession != null)
                    App.DB.Entry(paidSession).Reload();
                saved = true;
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                if (context.PaymentID == 0)
                    App.DB.Entry(context).State = EntityState.Detached;
                MessageBox.Show("Не удалось сохранить данные: " + App.GetError(ex), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void CBSession_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // подставляем остаток к оплате в поле суммы
            SessionItem item = CBSession.SelectedItem as SessionItem;
            if (item != null)
                TBAmount.Text = item.Remaining.ToString("F2");
        }
    }
}
