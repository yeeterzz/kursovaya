﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Data;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;

namespace KabinetPsychologistApp.Pages
{
    public partial class ServiceFormPage : Page
    {
        private Services context;
        private bool saved;

        public ServiceFormPage(Services item)
        {
            InitializeComponent();
            context = item;
            CBCategory.ItemsSource = App.DB.ProblemCategories.OrderBy(x => x.Name).ToList();

            var formats = new List<LookupItem> { new LookupItem { Id = null, Name = "— не указан —" } };
            formats.AddRange(App.DB.Formats.OrderBy(x => x.Name).ToList().Select(x => new LookupItem { Id = x.FormatID, Name = x.Name }));
            CBFormat.ItemsSource = formats;

            DataContext = context;
            TBTitle.Text = context.ServiceID == 0 ? "Новая услуга" : "Редактирование услуги";
            Unloaded += Page_Unloaded;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            // Если форму закрыли без сохранения - возвращаем объекту значения из БД
            if (saved || context.ServiceID == 0)
                return;
            try { App.DB.Entry(context).Reload(); }
            catch (Exception) { }
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            errorMessage += InputCheck.Text(context.Name, "Название", 200, true);

            if (context.CategoryID == 0)
                errorMessage += "Выберите категорию проблемы\n";

            if (Validation.GetHasError(TBDuration))
                errorMessage += "Длительность должна быть целым числом (минуты)\n";
            else if (context.DurationMin < 10 || context.DurationMin > 480)
                errorMessage += "Длительность должна быть от 10 до 480 минут\n";

            if (Validation.GetHasError(TBPrice))
                errorMessage += "Цена должна быть числом\n";
            else if (context.Price.HasValue && (context.Price.Value <= 0 || context.Price.Value > 1000000))
                errorMessage += "Цена должна быть больше 0 и не более 1 000 000\n";

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage, "Проверьте введённые данные", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                context.Name = context.Name.Trim();
                context.Description = InputCheck.NullIfEmpty(context.Description);
                if (context.ServiceID == 0)
                    App.DB.Services.Add(context);
                App.DB.SaveChanges();
                saved = true;
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                if (context.ServiceID == 0)
                    App.DB.Entry(context).State = EntityState.Detached;
                MessageBox.Show("Не удалось сохранить данные: " + App.GetError(ex), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

    }
}
