﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using KabinetPsychologistApp.Helpers;
using KabinetPsychologistApp.Models;

namespace KabinetPsychologistApp.Pages
{
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            TBLogin.Focus();
        }

        private void BLogin_Click(object sender, RoutedEventArgs e)
        {
            TBError.Text = "";
            string login = TBLogin.Text.Trim();
            string password = PBPassword.Password;

            if (login == "" || password == "")
            {
                TBError.Text = "Введите логин и пароль";
                return;
            }

            try
            {
                Users user = App.DB.Users.FirstOrDefault(x => x.Login == login);

                if (user == null || !PasswordHelper.Verify(password, user.PasswordHash))
                {
                    TBError.Text = "Неверный логин или пароль";
                    return;
                }

                if (user.Role == "Psychologist" && user.PsychologistID == null)
                {
                    TBError.Text = "Учётная запись не привязана к психологу. Обратитесь к администратору.";
                    return;
                }

                App.CurrentUser = user;
                PBPassword.Clear();
                NavigationService.Navigate(new MainPage());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось подключиться к базе данных:\n" + App.GetError(ex), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
