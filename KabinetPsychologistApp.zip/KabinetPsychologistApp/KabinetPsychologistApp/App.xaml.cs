﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Markup;
using KabinetPsychologistApp.Models;

namespace KabinetPsychologistApp
{
    public partial class App : Application
    {
        // Единая переменная для работы с БД (модель ADO.NET Entity Data Model)
        public static KabinetPsychologistEntities DB = new KabinetPsychologistEntities();

        // Пользователь, вошедший в систему
        public static Users CurrentUser;

        public static bool IsAdmin
        {
            get { return CurrentUser != null && CurrentUser.Role == "Admin"; }
        }

        // Текст самой глубокой вложенной ошибки (для SqlException это сообщение сервера)
        public static string GetError(Exception ex)
        {
            while (ex.InnerException != null)
                ex = ex.InnerException;
            return ex.Message;
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            // чтобы привязки (Binding) использовали региональные настройки Windows, а не en-US
            FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement),
                new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));
            base.OnStartup(e);
        }
    }
}
