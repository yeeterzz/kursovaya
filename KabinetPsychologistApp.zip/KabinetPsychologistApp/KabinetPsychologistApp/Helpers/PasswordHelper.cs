﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace KabinetPsychologistApp.Helpers
{
    public static class PasswordHelper
    {
        // SHA-256 в виде строки из 64 шестнадцатеричных символов (так же хранится в таблице Users)
        public static string Hash(string password)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder sb = new StringBuilder(bytes.Length * 2);
                foreach (byte b in bytes)
                    sb.Append(b.ToString("X2"));
                return sb.ToString();
            }
        }

        public static bool Verify(string password, string hash)
        {
            return hash != null && string.Equals(Hash(password), hash.Trim(), StringComparison.OrdinalIgnoreCase);
        }
    }
}
