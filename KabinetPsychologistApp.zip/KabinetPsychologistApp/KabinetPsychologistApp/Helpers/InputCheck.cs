﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace KabinetPsychologistApp.Helpers
{
    // Проверки вводимых значений. Каждый метод возвращает текст ошибки или пустую строку.
    public static class InputCheck
    {
        public static string Text(string value, string fieldName, int maxLength, bool required)
        {
            if (string.IsNullOrWhiteSpace(value))
                return required ? "Поле «" + fieldName + "» обязательно для заполнения\n" : "";
            if (value.Trim().Length > maxLength)
                return "Поле «" + fieldName + "» не должно быть длиннее " + maxLength + " символов\n";
            return "";
        }

        public static string Phone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone))
                return "";
            int digits = phone.Count(char.IsDigit);
            if (phone.Length > 50 || digits < 10 || digits > 15)
                return "Телефон должен содержать от 10 до 15 цифр\n";
            return "";
        }

        public static string Email(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return "";
            if (email.Trim().Length > 256 || !Regex.IsMatch(email.Trim(), @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                return "Введите корректный адрес электронной почты\n";
            return "";
        }

        public static string NullIfEmpty(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
        }
    }
}
