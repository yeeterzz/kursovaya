﻿using KabinetPsychologistApp.Models;

namespace KabinetPsychologistApp.Data
{
    // Строки таблиц на страницах-списках: сама запись (Entity) и названия из связанных таблиц

    public class PsychologistRow
    {
        public Psychologists Entity { get; set; }
        public string Specialization { get; set; }
    }

    public class ServiceRow
    {
        public Services Entity { get; set; }
        public string Category { get; set; }
        public string Format { get; set; }
    }

    public class SessionRow
    {
        public Sessions Entity { get; set; }
        public string Psychologist { get; set; }
        public string Client { get; set; }
        public string Service { get; set; }
        public string Paid { get; set; }
    }

    public class PaymentRow
    {
        public Payments Entity { get; set; }
        public string Client { get; set; }
        public string Psychologist { get; set; }
        public System.DateTime SessionDate { get; set; }
    }

    public class ReviewRow
    {
        public Reviews Entity { get; set; }
        public string Client { get; set; }
        public string Psychologist { get; set; }
        public string Service { get; set; }
    }

    public class UserRow
    {
        public Users Entity { get; set; }
        public string Psychologist { get; set; }
        public string RoleTitle { get; set; }
    }

    // Элементы выпадающих списков
    public class LookupItem
    {
        public int? Id { get; set; }
        public string Name { get; set; }
    }

    public class RoleItem
    {
        public string Code { get; set; }
        public string Title { get; set; }
    }

    public class SessionItem
    {
        public int SessionID { get; set; }
        public string Title { get; set; }
        public decimal Remaining { get; set; }
    }
}
