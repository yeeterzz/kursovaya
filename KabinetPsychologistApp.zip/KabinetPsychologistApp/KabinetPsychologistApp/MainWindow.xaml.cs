﻿using System.Windows;
using System.Windows.Navigation;
using KabinetPsychologistApp.Pages;

namespace KabinetPsychologistApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Navigating += MainFrame_Navigating;
            MainFrame.Navigate(new LoginPage());
        }

        // после выхода из системы нельзя вернуться назад (Alt+Стрелка влево) в окно с данными
        private void MainFrame_Navigating(object sender, NavigatingCancelEventArgs e)
        {
            if (!ReferenceEquals(e.Navigator, MainFrame))
                return;
            if (e.NavigationMode == NavigationMode.Back || e.NavigationMode == NavigationMode.Forward)
                e.Cancel = true;
        }
    }
}
